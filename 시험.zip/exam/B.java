//@RequiredArgsConstructor
//@Log4j2
//@Controller
//public class DeptController {
//    //    생성자 DI: 서비스
//    private final DeptService deptService;

//  추가 된 부분
//  1. @ RequiredArgsConstructor. @ Log4j2, @Controller