package com.simplecoding.simpledms.qna.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class QnaDto {
    private Long qno;
    private String QUESTIONER;
    private String QUESTION;
    private  String ANSWER;
    private  String ANSWERER;
}
