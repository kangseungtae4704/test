package com.simplecoding.simpledms.qna.service;

import com.simplecoding.simpledms.common.ErrorMsg;
import com.simplecoding.simpledms.common.MapStruct;
import com.simplecoding.simpledms.qna.dto.QnaDto;
import com.simplecoding.simpledms.qna.entity.Qna;
import com.simplecoding.simpledms.qna.repository.QnaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class QnaService {
    //    생성자 DI
    private final QnaRepository qnaRepository;
    private final MapStruct mapStruct;       // 복사 라이브러리
    private final ErrorMsg errorMsg;         // 에러메세지 화면표시 클래스

    //    전체조회(페이징): like 검색
//    spring: 매개변수(Criteria), 결과(PagenationInfo)
//    JPA   : 매개변수(Pageable), 결과(Page:결과배열, 현재페이지번호 등)
//    조회: DB 결과 -> 엔터티클래스 -> DTO 복사(생략) -> DTO로 화면에 표시
//     예)  dto.dno=dept.dno (복사) , 복사 라이브러리(엔티티 <-> DTO:MapStruct)
//    TODO: page.map(data->mapStruct.toDto(data)); 의미
//      스트림(자동반복문), for문으로 모두 변경(엔티티 -> DTO)
//      stream.map(실행문): 배열의 끝까지 자동 반복 실행
    public Page<QnaDto> selectQnaList(String searchKeyword,
                                       Pageable pageable) {
        Page<Qna> page=qnaRepository.selectQnaList(searchKeyword, pageable);
        return page.map(data->mapStruct.toDto(data));
    }
}
